<form name="form1" method="post" action="">
  <table width="50%" border="1">
  <?php
  foreach($da as $d)
  {
	  ?>
  
    <tr>
      <th colspan="2">Edit Details</th>
    </tr>
    <tr>
      <th colspan="2"><?= $msg;?></th>
    </tr>
    <tr>
      <td>Name</td>
      <td><input type="text" name="n2" id="n2" value="<?= $d['name'];?>"></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="text" name="e2" id="e2" value="<?= $d['email'];?>"></td>
    </tr>
    <tr>
      <td>Mobile</td>
      <td><input type="text" name="m2" id="m2" value="<?= $d['mobile'];?>"></td>
    </tr>
    <tr>
      <td>Remarks</td>
      <td><textarea name="t2" id="textarea" ><?= $d['remarks'];?></textarea></td>
    </tr>
    <tr>
      <th colspan="2"><input type="submit" name="sub" id="sub" value="Submit"></th>
    </tr>
    <?php
  }
    ?>
  </table>
</form>

 