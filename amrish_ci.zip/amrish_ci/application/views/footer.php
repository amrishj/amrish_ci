<!-- footer -->
      <div id="footer">
        <div class="indent">
          <div class="fleft">Designed by: &nbsp;<a href="http://www.templates.com/"><img alt="" src="<?= base_url();?>/fashion/images/t-com_logo.gif" /></a> &nbsp;Your provider of &nbsp;<a href="http://www.templates.com/">Website Templates</a></div>
          <div class="fright">Copyright &copy; <?php echo date('Y');?>- Amrish Jaysawal</div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>