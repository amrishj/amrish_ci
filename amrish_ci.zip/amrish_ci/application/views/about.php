   <div id="content">
        <div class="wrapper">
          <div class="col-1">
            <div class="section">
              <!-- <h1>About Us</h1> -->
              <?php echo heading('About Us', 1); ?>
           
              <p>This is about us page</p>
              <p>This is about us page</p>
              </div>
            </div>
          <div class="col-2">
            <div class="section">
             sidebar
            </div>
           
          </div>
        </div>
      </div>