
      <!-- content -->
      <div id="content">
        <div class="wrapper">
          <div class="col-1">
            <div class="section">
              <table width="100%" border="1">
                <tr>
                  <th colspan="8" scope="col">Contact Details</th>
                </tr>
                <tr>
                  <td><strong>S.no</strong></td>
                  <td><strong>Name</strong></td>
                  <td><strong>Email</strong></td>
                  <td><strong>Mobile</strong></td>
                  <td><strong>Remarks</strong></td>
                  <td><strong>Image</strong></td>
                  <td><strong>Date</strong></td>
                  <td><strong>Action</strong></td>
                </tr>
                <?php
				$s=1;
				foreach($da as $d)
				{
					?>
                    <tr>
                    <td><?= $s++;?></td>
                    <td><?= $d['name'];?></td>
                    <td><?= $d['email'];?></td>
                    <td><?= $d['mobile'];?></td>
                    <td><?= $d['remarks'];?></td>
                    <td><img src="fashion/cimages/<?= $d['image'];?>" height="50px" width="50px"/></td>
                    <td><?= $d['dat'];?></td>
                    <td><?= anchor("user/edit/".$d['id'],"Edit"); ?>&nbsp;<?= anchor("User/del/".$d['id'],"Delete");?></td>
                    </tr>         
					<?php
					// $s++;
					}
				
				?>
           </table>
            </div>
            </div>
          <div class="col-2">
            <div class="section">
             sidebar
            </div>
           
          </div>
        </div>
      </div>
      






