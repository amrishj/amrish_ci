<!-- content -->
      <div id="content">
        <div class="wrapper">
          <div class="col-1">
            <div class="section">
              <h2>Contact Us</h2>
              <form  method="post" enctype="multipart/form-data" name="form1">
                <table width="70%" border="1">
                  <tr>
                    <th colspan="2"><?= $msg;?></th>
                  </tr>
                  <tr>
                    <td><strong>Name</strong></td>
                    <td><input name="n1" type="text" ></td>
                  </tr>
                  <tr>
                    <td><strong>Email</strong></td>
                    <td><input name="e1" type="email" ></td>
                  </tr>
                 
                  <tr>
                    <td><strong>Mobile</strong></td>
                    <td><input name="m1" type="number" ></td>
                  </tr>
                  <tr>
                    <td><strong>Remarks</strong></td>
                    <td><textarea name="r1" cols="45" rows="5" ></textarea></td>
                  </tr>
                  <tr>
                    <td><strong>Image</strong></td>
                    <td><input type="file" name="att" ></td>
                  </tr>
                  <tr>
                    <th colspan="2"><input type="submit" name="sub"  value="Submit"></th>
                  </tr>
                </table>
              </form>
            </div>
            </div>
          <div class="col-2">
            <div class="section">
             sidebar
            </div>
           
          </div>
        </div>
      </div>
      