<?php
defined("BASEPATH") or die("Not allowed");
class My_model extends CI_Model
{
	function con($n,$e,$m,$r,$i)
	{
		$data=['name'=>$n,
		'email'=>$e,
		'mobile'=>$m,
		'remarks'=>$r,
		'image'=>$i
	    ];
		return $this->db->insert("contact_db",$data);
		
		}
	function fetch()
	{
		$sel=$this->db->get("contact_db");
		return $sel->result_array();		
		}
	function del($i)
	{
		return $this->db->delete("contact_db",['id'=>$i]);
		
	}
	function show($i)
	{
		$sel=$this->db->get_where("contact_db",['id'=>$i]);	
		return $sel->result_array();	
		
		
		}
	function edit($n,$e,$m,$r,$i)
	{
		
		$data=['name'=>$n,
		'email'=>$e,
		'mobile'=>$m,
		'remarks'=>$r];
		$this->db->where('id', $i);
        return $this->db->update("contact_db",$data);

		
		}
}


?>