<?php
defined("BASEPATH") or die("Not allowed");
class User extends CI_Controller
{
		function index()
		{
		$data['da']=$this->My_Model->fetch();
		$this->load->view("header.php");
		$this->load->view("front",$data);
		$this->load->view("footer");
		}
		function contact()
		{
			$data['msg']="";
			extract($_POST);
			if(isset($sub))
			{
				  $this->form_validation->set_rules('n1', 'name','required|min_length[5]|max_length[15]|is_unique[contact_db.name]');
                $this->form_validation->set_rules('e1', 'email', 'required');
                $this->form_validation->set_rules('m1', 'mobile', 'required');
                $this->form_validation->set_rules('r1', 'remarks', 'required');

                if ($this->form_validation->run() == false)
                {
                        $data['msg']=validation_errors();
                }
                else
                {
                	$att=$_FILES['att']['name'];
                 $config['upload_path']  = './fashion/cimages/';
                $config['allowed_types']        = 'gif|jpg|png|pdf';
						
               // $config['max_size']             = 100;
               // $config['max_width']            = 1024;
               // $config['max_height']           = 768;

                $this->load->library('upload', $config);
				if($this->upload->do_upload('att')) 
				{
				
					if($this->My_Model->con($n1,$e1,$m1,$r1,$att))
					{
						$data['msg']="Contact send";
					}
					else
					{
						$data['msg']="Contact not send";
						
					}
					
				}
				else{
					$data['msg']="image is not correct";
										
					}
					
				}
				}
				
			$this->load->view("header");
			$this->load->view("contact",$data);
		    $this->load->view("footer");
			
			}
			function del($i)
				{
					if($i!="")
					{
						if($this->My_Model->del($i))
						{
							redirect("User/index");
							}
						}
				}
				function edit($i)
				{  
				$data['da']=$this->My_Model->show($i);
				
				     $data['msg']="";
					 extract($_POST);
					if(isset($sub))
					{
					if($this->My_Model->edit($n2,$e2,$m2,$t2,$i))
					{
						$data["msg"]="Updated";
										
					}
						else
						{
							$data["msg"]="Not Updated";
						}
					}
								
					$this->load->view("header");
			        $this->load->view("update",$data);
			        $this->load->view("footer");
        }
		function about()
		{
			
			$this->load->view("header.php");
			$this->load->view("about");
			$this->load->view("footer");
			}
	}



?>

